clear all;
%output folders
result_path = 'C:\My data\CIC2015\HDR color apearance\SAMVIQ_iTMO_CAM\samviq_updated\results\';
output_path = 'C:\My data\CIC2015\HDR color apearance\SAMVIQ_iTMO_CAM\figures\';

d = dir(result_path);
isub = [d(:).isdir];
name_obs = {d(isub).name}';
name_obs(ismember(name_obs,{'.','..'})) = [];
length(name_obs)
all_results = zeros(length(name_obs),10,9);
for l = 1:length(name_obs)
    
    srcin = dir([result_path,name_obs{l},'\','*.bmp.mat']);
    for i = 1:length(srcin)
        load([result_path,name_obs{l},'\',srcin(i).name])
          all_results(l,i,:) = scores.all_scores;
    end

end
save ('all_results.mat','all_results');

Methods = {'Akyuz','Banterle', 'Landis', 'Meylan', 'Rempel', 'fwd',  'input', 'kim', 'ref'};
Scenes = {'8','9', '1', '7', '6', '10',  '2', '3', '4', '5'};

mean_score_methods = zeros(10,9);

for i=1:10
    for j=1:9
        mean_score_methods(i,j) = mean(all_results(:,i,j));
    end
    figure,
    str = {'Akyuz';'Banterle'; 'Landis'; 'Meylan'; 'Rempel'; 'Renhard';  'LDR'; 'kim'; 'Ref'};
    bar(mean_score_methods(i,:)),xlabel(''),ylabel('Mean Score'),title(strcat('Scene number:  ',Scenes(i)));
%     legend('Akyuz','Banterle', 'Landis', 'Meylan', 'Rempel', 'fwd',  'input', 'kim', 'ref')
    ylim([0,100])
    set(gca, 'XTickLabel',str, 'XTick',1:numel(str))
    saveas(gcf, strcat(output_path,Scenes{i},'_score'), 'eps')
%     print('BarPlot','-depsc')
end



mean_scores_all = zeros(9);
for i=1:9
    mean_score_all(i) = mean(mean_score_methods(:,i));
    std_score_all(i) = std(mean_score_methods(:,i));
end
figure,
str = {'Akyuz';'Banterle'; 'Landis'; 'Meylan'; 'Rempel'; 'Renhard';  'LDR'; 'kim'; 'Ref'};
bar(mean_score_all),xlabel(''),ylabel('Mean Score'),title('Mean observer scores of the Methods');
ylim([0,100])
set(gca, 'XTickLabel',str, 'XTick',1:numel(str))
saveas(gcf, strcat(output_path,'all_score'), 'eps')
